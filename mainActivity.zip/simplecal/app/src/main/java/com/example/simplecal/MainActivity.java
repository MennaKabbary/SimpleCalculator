package com.example.simplecal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import android.view.View;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    public Button button;
    Button buttonAdd, buttonSub, buttonMulti, buttonDiv;
    EditText editTextN1, editTextN2;
    TextView textView;
    int num1, num2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonAdd =findViewById(R.id.btn_add);
        buttonSub =findViewById(R.id.btn_sub);
        buttonMulti =findViewById(R.id.btn_multi);
        buttonDiv =findViewById(R.id.btn_div);
        editTextN1 = findViewById(R.id.number1);
        editTextN2 = findViewById(R.id.number2);
        textView = findViewById(R.id.answer);
        button = (Button) findViewById(R.id.btn_ans);


        buttonAdd.setOnClickListener(this);
        buttonSub.setOnClickListener(this);
        buttonMulti.setOnClickListener(this);
        buttonDiv.setOnClickListener(this);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Integer integer = textView.getSelectionEnd();
                Intent intent = new Intent(MainActivity.this,MainActivity2.class);
                startActivity(intent);
            }
        });
    }
    public int getIntFromEditText(EditText editText){
        if (editTextN1.getText().toString().equals("")){
            Toast.makeText(this, "Enter number", Toast.LENGTH_SHORT).show();
            return 0;
        }else
            return Integer.parseInt(editText.getText().toString());
    }

    @Override
    public void onClick(View view) {
        num1 = getIntFromEditText(editTextN1);
        num2 = getIntFromEditText(editTextN2);
        switch (view.getId()){
            case R.id.btn_add:
                textView.setText("Answer = " + (num1 + num2));
                break;
            case R.id.btn_sub:
                textView.setText("Answer = " + (num1 - num2));
                break;
            case R.id.btn_multi:
                textView.setText("Answer = " + (num1 * num2));
                break;
            case R.id.btn_div:
                textView.setText("Answer = " + (num1 / num2));
                break;
  }
}

}